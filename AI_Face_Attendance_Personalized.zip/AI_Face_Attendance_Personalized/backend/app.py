import os, cv2, numpy as np, face_recognition, datetime, csv
from flask import Flask, render_template, request, jsonify, send_file
from pathlib import Path

app = Flask(__name__)
UPLOADS = Path("backend/uploads")
EXPORTS = Path("backend/exports")
ENCODINGS = Path("backend/encodings_store")

UPLOADS.mkdir(exist_ok=True)
EXPORTS.mkdir(exist_ok=True)
ENCODINGS.mkdir(exist_ok=True)

# Load known encodings
def load_known_faces():
    known_encodings, known_names = [], []
    for img_file in ENCODINGS.glob("*.*"):
        img = face_recognition.load_image_file(img_file)
        enc = face_recognition.face_encodings(img)
        if enc:
            known_encodings.append(enc[0])
            known_names.append(img_file.stem)
    return known_encodings, known_names

known_encodings, known_names = load_known_faces()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload_photo', methods=['POST'])
def upload_photo():
    global known_encodings, known_names
    if 'photo' not in request.files:
        return jsonify({'error': 'No file uploaded'})
    file = request.files['photo']
    filename = file.filename
    save_path = UPLOADS / filename
    file.save(save_path)

    img = face_recognition.load_image_file(save_path)
    locs = face_recognition.face_locations(img)
    encs = face_recognition.face_encodings(img, locs)

    marked_names = []
    for enc in encs:
        matches = face_recognition.compare_faces(known_encodings, enc, tolerance=0.5)
        if True in matches:
            name = known_names[matches.index(True)]
            marked_names.append(name)
            mark_attendance(name)
        else:
            marked_names.append("Unknown")

    return jsonify({'message': f"Attendance marked for: {', '.join(marked_names)}"})

def mark_attendance(name):
    today = datetime.date.today().strftime("%Y-%m-%d")
    file_path = EXPORTS / f"attendance_{today}.csv"
    exists = file_path.exists()
    with open(file_path, 'a', newline='') as f:
        writer = csv.writer(f)
        if not exists:
            writer.writerow(["Name", "Time"])
        writer.writerow([name, datetime.datetime.now().strftime("%H:%M:%S")])

@app.route('/export_attendance')
def export_attendance():
    today = datetime.date.today().strftime("%Y-%m-%d")
    file_path = EXPORTS / f"attendance_{today}.csv"
    if file_path.exists():
        return send_file(file_path, as_attachment=True)
    return jsonify({'error': 'No attendance file yet'})

@app.route('/reload_encodings')
def reload_encodings():
    global known_encodings, known_names
    known_encodings, known_names = load_known_faces()
    return jsonify({'message': f'Reloaded {len(known_names)} encodings'})

if __name__ == "__main__":
    app.run(debug=True)
