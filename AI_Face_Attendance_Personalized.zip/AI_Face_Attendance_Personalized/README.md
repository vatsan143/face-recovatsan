# AI-Based Classroom Attendance

### 🧩 How to Run
1. Create a virtual environment:
   python -m venv venv
   venv\Scripts\activate
2. Install dependencies:
   pip install -r requirements.txt
3. Run Flask backend:
   python backend/app.py
4. Open in browser:
   http://127.0.0.1:5000/
